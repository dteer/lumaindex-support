-- 接收图库主动选图：只处理随机交接编号，文件路径由当前本机图库提供。
local Tasks = import 'LrTasks'
local App = import 'LrApplication'
local Dialogs = import 'LrDialogs'
local Http = import 'LrHttp'
local Json = dofile(_PLUGIN.path .. '/Json.lua')
local Bridge = dofile(_PLUGIN.path .. '/Bridge.lua')

-- receive 在异步 SDK 上下文内复用目录照片及已有调整；缺失照片才导入。
local function receive(id, connection, outcome)
    local body = Http.get(connection.baseURL .. '/api/v1/lightroom/handoffs/' .. id, {
        { field = 'X-Luma-Instance', value = connection.instanceToken },
    }, 30)
    local ok, response = pcall(Json.decode, body)
    assert(ok and type(response) == 'table' and response.code == 0 and type(response.data) == 'table',
        '选图已过期或图库已切换，请回到图库重新点击 Lightroom Classic。')
    local paths = response.data.paths
    assert(type(paths) == 'table' and #paths > 0 and #paths <= 500, '选图内容无效，请重新选择。')
    for _, path in ipairs(paths) do
        assert(type(path) == 'string' and path:sub(1, 1) == '/', '原图路径无效。')
    end
    outcome.errorCode = 'catalog_unavailable'
    local catalog = assert(App.activeCatalog(), '请先打开 Lightroom 目录。')
    outcome.errorCode = 'import_failed'
    local photos, collection = {}, nil
    -- 独立集合让本次多选在 LR 当前来源中可见，不修改既有收藏集与调整。
    catalog:withWriteAccessDo('有序图库：接收原图', function()
        local set = catalog:createCollectionSet('有序图库', nil, true)
        collection = catalog:createCollection('本次修图 ' .. id, set, true)
        for _, path in ipairs(paths) do
            local photo = catalog:findPhotoByPath(path)
            if not photo then photo = catalog:addPhoto(path) end
            assert(photo, '部分原图未能导入，请确认文件仍可访问。')
            photos[#photos + 1] = photo
        end
        collection:addPhotos(photos)
    end, { timeout = 30 })
    assert(collection and #photos == #paths, 'Lightroom 目录正在忙，请稍后重新打开。')
    outcome.errorCode = 'selection_failed'
    catalog:setActiveSources({ collection })
    -- 切换来源后 LR 的选中状态可能尚未更新；让出执行权后重试，并读取真实目标确认。
    local expected = {}
    for _, photo in ipairs(photos) do expected[photo.localIdentifier] = true end
    for attempt = 1, 20 do
        catalog:setSelectedPhotos(photos[1], photos)
        Tasks.sleep(0.1)
        local active, targets = catalog:getTargetPhoto(), catalog:getTargetPhotos()
        local matches = active and active.localIdentifier == photos[1].localIdentifier and #targets == #photos
        for _, target in ipairs(targets) do
            if not expected[target.localIdentifier] then matches = false end
        end
        if matches then
            outcome.success, outcome.count, outcome.errorCode = true, #photos, nil
            return
        end
    end
    error('Lightroom 尚未选中目标原图，请关闭弹窗或检查当前筛选后重试。')
end

-- report 只向已验证的本机图库提交结果码，不发送原图路径、Lua 错误或内部诊断。
local function report(connection, id, outcome)
    local body = Http.post(connection.baseURL .. '/api/v1/lightroom/handoffs/' .. id .. '/result', Json.encode(outcome), {
        { field = 'Content-Type', value = 'application/json' },
        { field = 'X-Luma-Instance', value = connection.instanceToken },
    }, 'POST', 5)
    local ok, response = pcall(Json.decode, body)
    return ok and type(response) == 'table' and response.code == 0
end

return {
    -- URLHandler 由 Info.lua 注册，仅用户显式打开图库链接后执行。
    URLHandler = function(url)
        Tasks.startAsyncTask(function()
            local id = type(url) == 'string' and url:match('^lightroom://com%.lumaindex%.lightroom/handoff/([A-Z0-9]+)$')
            if not id or #id ~= 26 then
                Dialogs.message('有序图库', '选图链接无效，请在图库重新选择图片。', 'critical')
                return
            end
            local connection, message = Bridge.current()
            if not connection then Dialogs.message('有序图库', message, 'critical'); return end
            local outcome = { success = false, count = 0, errorCode = 'plugin_error' }
            local ok = Tasks.pcall(function() receive(id, connection, outcome) end)
            local reportOK, reported = Tasks.pcall(function() return report(connection, id, outcome) end)
            if not ok then
                Dialogs.message('有序图库', '未能定位全部原图，请关闭 Lightroom 弹窗、确认文件可访问后重试。', 'critical')
            elseif not reportOK or not reported then
                Dialogs.message('有序图库', '原图已选中，但图库未收到确认。请使用新版图库后重新发起。', 'warning')
            end
        end)
    end,
}
