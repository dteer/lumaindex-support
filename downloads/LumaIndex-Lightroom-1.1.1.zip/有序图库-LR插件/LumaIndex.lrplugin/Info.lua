-- Lightroom Classic 导出服务；不适用于云版 Lightroom。
return {
    LrSdkVersion = 6.0,
    LrSdkMinimumVersion = 6.0,
    LrToolkitIdentifier = 'com.lumaindex.lightroom',
    LrPluginName = '有序图库',
    URLHandler = 'Handoff.lua',
    VERSION = { major = 1, minor = 1, revision = 1, build = 1 },
    LrExportServiceProvider = {
        title = '有序图库',
        file = 'ExportService.lua',
    },
    LrExportMenuItems = {
        { title = '有序图库：检查连接', file = 'CheckConnection.lua' },
        { title = '有序图库：重试未完成回传', file = 'Retry.lua' },
    },
}
