-- 接收图库主动选图：只处理随机交接编号，文件路径由当前本机图库提供。
local Tasks = import 'LrTasks'
local App = import 'LrApplication'
local Dialogs = import 'LrDialogs'
local Http = import 'LrHttp'
local Json = dofile(_PLUGIN.path .. '/Json.lua')
local Bridge = dofile(_PLUGIN.path .. '/Bridge.lua')

-- receive 在异步 SDK 上下文内复用目录照片及已有调整；缺失照片才导入。
local function receive(url)
    local id = type(url) == 'string' and url:match('^lightroom://com%.lumaindex%.lightroom/handoff/([A-Z0-9]+)$')
    assert(id and #id == 26, '选图链接无效，请在图库重新选择图片。')
    local connection, message = Bridge.current()
    assert(connection, message)
    local body = Http.get(connection.baseURL .. '/api/v1/lightroom/handoffs/' .. id, {
        { field = 'X-Luma-Instance', value = connection.instanceToken },
    }, 30)
    local ok, response = pcall(Json.decode, body)
    assert(ok and type(response) == 'table' and response.code == 0 and type(response.data) == 'table',
        '选图已过期或图库已切换，请回到图库重新点击 Lightroom Classic。')
    local paths = response.data.paths
    assert(type(paths) == 'table' and #paths > 0 and #paths <= 500, '选图内容无效，请重新选择。')
    for _, path in ipairs(paths) do
        assert(type(path) == 'string' and path:sub(1, 1) == '/', '原图路径无效。')
    end
    local catalog = App.activeCatalog()
    local photos, collection = {}, nil
    -- 独立集合让本次多选在 LR 当前来源中可见，不修改既有收藏集与调整。
    catalog:withWriteAccessDo('有序图库：接收原图', function()
        local set = catalog:createCollectionSet('有序图库', nil, true)
        collection = catalog:createCollection('本次修图 ' .. id, set, true)
        for _, path in ipairs(paths) do
            local photo = catalog:findPhotoByPath(path)
            if not photo then photo = catalog:addPhoto(path) end
            assert(photo, '部分原图未能导入，请确认文件仍可访问。')
            photos[#photos + 1] = photo
        end
        collection:addPhotos(photos)
    end, { timeout = 30 })
    assert(collection and #photos == #paths, 'Lightroom 目录正在忙，请稍后重新打开。')
    catalog:setActiveSources({ collection })
    catalog:setSelectedPhotos(photos[1], photos)
end

return {
    -- URLHandler 由 Info.lua 注册，仅用户显式打开图库链接后执行。
    URLHandler = function(url)
        Tasks.startAsyncTask(function()
            local ok, message = Tasks.pcall(function() receive(url) end)
            if not ok then Dialogs.message('有序图库', tostring(message), 'critical') end
        end)
    end,
}
