#!/bin/zsh
# 将随包插件安装到当前用户的 Lightroom Modules；不修改其他插件或用户偏好。
set -euo pipefail
installer_dir="${0:A:h}"
modules_dir="$HOME/Library/Application Support/Adobe/Lightroom/Modules"
if (( $# > 0 )); then
  [[ $# == 2 && "$1" == "--destination" && "$2" == /* ]] || { print -u2 -- '用法：安装插件.command [--destination 绝对目录]'; exit 1; }
  modules_dir="$2"
fi
plugin_source="$installer_dir/LumaIndex.lrplugin"
plugin_target="$modules_dir/LumaIndex.lrplugin"
[[ -f "$plugin_source/Info.lua" && ! -L "$plugin_source" ]] || { print -u2 -- '找不到随包插件，请完整解压后再安装。'; exit 1; }
[[ ! -L "$modules_dir" && ! -L "$plugin_target" ]] || { print -u2 -- '安装目标是符号链接，请改用 Lightroom 增效工具管理器手动添加。'; exit 1; }
if [[ -e "$plugin_target" ]]; then
  [[ -f "$plugin_target/Info.lua" ]] && /usr/bin/grep -Fq 'com.lumaindex.lightroom' "$plugin_target/Info.lua" || { print -u2 -- '目标目录不是有序图库插件，未作修改。'; exit 1; }
fi
mkdir -p "$modules_dir"
install_stage="$(mktemp -d "$modules_dir/.luma-install.XXXXXX")"
plugin_backup=""
# 安装失败时恢复旧版本；正常完成后清理本次暂存目录。
finish_install() {
  local result=$?
  if (( result != 0 )) && [[ -n "$plugin_backup" && -d "$plugin_backup" && ! -e "$plugin_target" ]]; then
    mv "$plugin_backup" "$plugin_target"
  fi
  rm -rf -- "$install_stage"
  return $result
}
trap finish_install EXIT
/usr/bin/ditto "$plugin_source" "$install_stage/LumaIndex.lrplugin"
if [[ -d "$plugin_target" ]]; then
  plugin_backup="$install_stage/previous.lrplugin"
  mv "$plugin_target" "$plugin_backup"
fi
mv "$install_stage/LumaIndex.lrplugin" "$plugin_target"
print -- '有序图库 Lightroom Classic 插件已安装。'
print -- "安装位置：$plugin_target"
print -- '请重启 Lightroom Classic，在导出窗口的“导出到”中选择“有序图库”。'
print -- '如未显示，在“文件 → 增效工具管理器”中添加上述插件目录。'
print -- '打开新版有序图库并进入目标图库后，即可导出回传。'
if [[ -t 0 ]]; then
  read -r '?按回车键关闭此窗口。'
fi
