-- 定位诊断仅记录处理阶段，不记录图片路径、链接或凭据。
local logger = import 'LrLogger' ('LumaIndexHandoff')
logger:enable('logfile')
logger:info('handler module loaded')
-- 接收图库主动选图：只处理随机交接编号，文件路径由当前本机图库提供。
local Tasks = import 'LrTasks'
local App = import 'LrApplication'
local AppView = import 'LrApplicationView'
local Dialogs = import 'LrDialogs'
local Http = import 'LrHttp'
local Json = dofile(_PLUGIN.path .. '/Json.lua')
local Bridge = dofile(_PLUGIN.path .. '/Bridge.lua')

-- receive 在异步 SDK 上下文内复用目录照片及已有调整；缺失照片才导入。
local function receive(id, connection, outcome)
    local body = Http.get(connection.baseURL .. '/api/v1/lightroom/handoffs/' .. id, {
        { field = 'X-Luma-Instance', value = connection.instanceToken },
    }, 30)
    local ok, response = pcall(Json.decode, body)
    assert(ok and type(response) == 'table' and response.code == 0 and type(response.data) == 'table',
        '选图已过期或图库已切换，请回到图库重新点击 Lightroom Classic。')
    -- 同一交接可能因冷启动补发多次；只有后端首次认领者执行选图。
    logger:info('claim ' .. tostring(response.data.shouldProcess) .. ' status ' .. tostring(response.data.status))
    if not response.data.shouldProcess then return false end
    local paths = response.data.paths
    assert(type(paths) == 'table' and #paths > 0 and #paths <= 500, '选图内容无效，请重新选择。')
    for _, path in ipairs(paths) do
        assert(type(path) == 'string' and path:sub(1, 1) == '/', '原图路径无效。')
    end
    outcome.errorCode = 'catalog_unavailable'
    logger:info('catalog lookup')
    local catalog = assert(App.activeCatalog(), '请先打开 Lightroom 目录。')
    outcome.errorCode = 'import_failed'
    local photos, missing = {}, {}
    -- 已导入原图的定位只读目录，避免为临时收藏集等待写锁。
    for index, path in ipairs(paths) do
        photos[index] = catalog:findPhotoByPath(path)
        if not photos[index] then missing[#missing + 1] = index end
    end
    if #missing > 0 then
        logger:info('import required')
        catalog:withWriteAccessDo('有序图库：导入原图', function()
            for _, index in ipairs(missing) do
                photos[index] = catalog:findPhotoByPath(paths[index]) or catalog:addPhoto(paths[index])
            end
        end, { timeout = 5 })
    end
    for index = 1, #paths do
        assert(photos[index], 'Lightroom 目录正在忙，原图尚未导入，请稍后重试。')
    end
    outcome.errorCode = 'selection_failed'
    local sources, seenFolders = {}, {}
    for _, path in ipairs(paths) do
        local parent = path:match('^(.*)/[^/]+$')
        if not seenFolders[parent] then
            local folder = catalog:getFolderByPath(parent)
            assert(folder, 'Lightroom 未找到原图文件夹。')
            sources[#sources + 1], seenFolders[parent] = folder, true
        end
    end
    -- 冷启动恢复窗口时图库模块可能尚未实例化；显式进入图库并有界等待。
    logger:info('activate library module')
    local activated = false
    for attempt = 1, 40 do
        local ready, changed = Tasks.pcall(function()
            AppView.switchToModule('library')
            Tasks.sleep(0.25)
            return catalog:setActiveSources(sources)
        end)
        if ready and changed ~= false then activated = true; break end
    end
    assert(activated, 'Lightroom 图库模块尚未就绪，请完成启动后重试。')
    -- 切换来源后 LR 的选中状态可能尚未更新；让出执行权后重试，并读取真实目标确认。
    local expected = {}
    for _, photo in ipairs(photos) do expected[photo.localIdentifier] = true end
    for attempt = 1, 20 do
        logger:info('select attempt ' .. attempt)
        catalog:setSelectedPhotos(photos[1], photos)
        Tasks.sleep(0.1)
        local active, targets = catalog:getTargetPhoto(), catalog:getTargetPhotos()
        local matches = active and active.localIdentifier == photos[1].localIdentifier and #targets == #photos
        for _, target in ipairs(targets) do
            if not expected[target.localIdentifier] then matches = false end
        end
        if matches then
            outcome.success, outcome.count, outcome.errorCode = true, #photos, nil
            return true
        end
    end
    error('Lightroom 尚未选中目标原图，请关闭弹窗或检查当前筛选后重试。')
end

-- report 只向已验证的本机图库提交结果码，不发送原图路径、Lua 错误或内部诊断。
local function report(connection, id, outcome)
    local body = Http.post(connection.baseURL .. '/api/v1/lightroom/handoffs/' .. id .. '/result', Json.encode(outcome), {
        { field = 'Content-Type', value = 'application/json' },
        { field = 'X-Luma-Instance', value = connection.instanceToken },
    }, 'POST', 5)
    local ok, response = pcall(Json.decode, body)
    return ok and type(response) == 'table' and response.code == 0
end

return {
    -- URLHandler 由 Info.lua 注册，仅用户显式打开图库链接后执行。
    URLHandler = function(url)
        logger:info('URL received')
        Tasks.startAsyncTask(function()
            local id = type(url) == 'string' and url:match('^lightroom://com%.lumaindex%.lightroom/handoff/([A-Z0-9]+)$')
            if not id or #id ~= 26 then
                Dialogs.message('有序图库', '选图链接无效，请在图库重新选择图片。', 'critical')
                return
            end
            logger:info('async started')
            local connection, message = Bridge.current()
            logger:info(connection and 'connection ready' or 'connection unavailable')
            if not connection then Dialogs.message('有序图库', message, 'critical'); return end
            local outcome = { success = false, count = 0, errorCode = 'plugin_error' }
            local ok, processed = Tasks.pcall(function() return receive(id, connection, outcome) end)
            if ok and not processed then return end
            logger:info(ok and 'receive complete' or 'receive failed')
            local reportOK, reported = Tasks.pcall(function() return report(connection, id, outcome) end)
            if not ok then
                Dialogs.message('有序图库', '未能定位全部原图，请关闭 Lightroom 弹窗、确认文件可访问后重试。', 'critical')
            elseif not reportOK or not reported then
                Dialogs.message('有序图库', '原图已选中，但图库未收到确认。请使用新版图库后重新发起。', 'warning')
            end
        end)
    end,
}
