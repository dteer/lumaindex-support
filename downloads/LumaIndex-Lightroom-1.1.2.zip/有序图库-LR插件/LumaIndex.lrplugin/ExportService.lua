-- 导出服务只接收 LR 已渲染的图片，不修改 LR 原图、目录库或编辑参数。
local Dialogs = import 'LrDialogs'
local Tasks = import 'LrTasks'
local Bridge = dofile(_PLUGIN.path .. '/Bridge.lua')

local function processRenderedPhotos(_, exportContext)
    local ok, message = Bridge.guarded(function()
        local connection, connectionError = Bridge.current()
        assert(connection, connectionError)
        local progress = exportContext:configureProgress { title = '正在回传有序图库' }
        local batch, renditions = {}, {}
        local succeeded, failed, cleanup = 0, 0, 0
        local failures = {}
        -- flush 保持逐项结果与 LR rendition 一致，不把部分成功当成整批成功。
        local function flush()
            if #batch == 0 then return end
            local manifestPath = Bridge.persist(connection, batch)
            for _, outcome in ipairs(Bridge.send(connection, manifestPath)) do
                local rendition = renditions[outcome.item.retouchedPath]
                if outcome.success then
                    succeeded = succeeded + 1
                    if outcome.cleanupPending then cleanup = cleanup + 1 end
                else
                    failed = failed + 1
                    rendition:uploadFailed(outcome.message)
                    failures[#failures + 1] = outcome.message
                end
            end
            batch, renditions = {}, {}
        end
        for _, rendition in exportContext:renditions { stopIfCanceled = true } do
            local rendered, pathOrError = rendition:waitForRender()
            if rendered then
                local staged, job = Tasks.pcall(function()
                    return Bridge.stage(rendition.photo:getRawMetadata('path'), pathOrError, connection)
                end)
                if staged then
                    batch[#batch + 1] = job
                    renditions[job.retouchedPath] = rendition
                    if #batch == 100 then flush() end
                else
                    failed = failed + 1
                    rendition:uploadFailed(tostring(job))
                    failures[#failures + 1] = tostring(job)
                end
            else
                failed = failed + 1
                rendition:uploadFailed(pathOrError)
                failures[#failures + 1] = tostring(pathOrError)
            end
        end
        -- 取消时不再提交已经暂存的剩余项，保留清单供手动重试。
        if not progress:isCanceled() then flush()
        elseif #batch > 0 then Bridge.persist(connection, batch) end
        progress:done()
        local summary = string.format('已接收 %d 张，失败 %d 张。', succeeded, failed)
        if cleanup > 0 then summary = summary .. '\n部分临时文件尚未清理，可点击“重试未完成回传”。' end
        if #batch > 0 then summary = summary .. '\n已取消；尚未提交的临时成片已保留，可稍后重试。' end
        if #failures > 0 then summary = summary .. '\n' .. failures[1] .. '\n使用“文件 → 增效工具额外信息 → 有序图库：重试未完成回传”。' end
        Dialogs.message('有序图库', summary, failed > 0 and 'warning' or 'info')
    end)
    if not ok then Dialogs.message('有序图库', tostring(message), 'critical') end
end

return {
    hideSections = { 'exportLocation', 'fileNaming', 'video' },
    allowFileFormats = { 'JPEG', 'TIFF' },
    allowColorSpaces = { 'sRGB', 'AdobeRGB', 'ProPhotoRGB' },
    canExportVideo = false,
    startDialog = function(properties)
        if properties.LR_format ~= 'JPEG' and properties.LR_format ~= 'TIFF' then properties.LR_format = 'JPEG' end
    end,
    sectionsForTopOfDialog = function(factory)
        return {
            { title = '回传到有序图库',
                factory:static_text { title = '请先在有序图库中打开目标图库。成片将自动关联原图所在的集合。', wrap_width = 430 },
                factory:static_text { title = '临时文件：原图名_毫秒时间戳_随机数；最终文件：修图/原图名_递增序号。', wrap_width = 430 },
            },
        }
    end,
    processRenderedPhotos = processRenderedPhotos,
}
