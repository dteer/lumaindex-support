-- SDK 边界：连接发现、持久交接清单与批量请求。只在用户导出或点击重试时联网。
local Files = import 'LrFileUtils'
local Paths = import 'LrPathUtils'
local Http = import 'LrHttp'
local Date = import 'LrDate'
local Tasks = import 'LrTasks'
local Json = dofile(_PLUGIN.path .. '/Json.lua')
local Core = dofile(_PLUGIN.path .. '/Core.lua')
local Bridge = {}
local home = Paths.getStandardFilePath('home')
local jobsDirectory = Paths.child(home, 'Library/Application Support/LumaIndex/LightroomPlugin/pending')
local lastStamp = 0

-- readJSON 安全读取配置，不执行文件内容。
local function readJSON(path)
    local success, result = pcall(function() return Json.decode(Files.readFile(path)) end)
    if success then return result end
end

-- current 从应用沙箱或开发环境的连接描述中选择最近一次就绪的图库，并验证进程身份。
function Bridge.current()
    local candidates = {
        Paths.child(home, 'Library/Containers/com.lumaindex.app/Data/Library/Application Support/LumaIndex/lightroom-connection.json'),
        Paths.child(home, 'Library/Application Support/LumaIndex/lightroom-connection.json'),
    }
    local connections = {}
    for _, path in ipairs(candidates) do
        local connection = readJSON(path)
        if Core.validConnection(connection) then connections[#connections + 1] = connection end
    end
    table.sort(connections, function(a, b) return (a.publishedAt or 0) > (b.publishedAt or 0) end)
    for _, connection in ipairs(connections) do
        local body = Http.get(connection.baseURL .. '/health/ready', nil, 3)
        local ok, health = pcall(Json.decode, body)
        if ok and type(health) == 'table' and health.code == 0 and type(health.data) == 'table'
            and health.data.status == 'ok' and health.data.instanceToken == connection.instanceToken then
            return connection
        end
    end
    return nil, '请打开新版有序图库并进入目标图库，再重试。'
end

-- stage 将 LR 会自动清理的渲染文件复制到图库提供的统一暂存目录，返回供清单持久化的路径映射。
function Bridge.stage(originalPath, renderedPath, connection)
    assert(type(originalPath) == 'string' and originalPath:sub(1, 1) == '/', '原图绝对路径不可用')
    local directory = connection.stagingDirectory
    Files.createAllDirectories(directory)
    Files.createAllDirectories(jobsDirectory)
    local milliseconds = (Date.currentTime() + 978307200) * 1000
    local name, stamp = Core.temporaryName(originalPath, renderedPath, milliseconds, lastStamp)
    local destination = Paths.child(directory, name)
    while Files.exists(destination) or Files.exists(destination .. '.partial') do
        name, stamp = Core.temporaryName(originalPath, renderedPath, milliseconds, stamp)
        destination = Paths.child(directory, name)
    end
    lastStamp = stamp
    local partial = destination .. '.partial'
    local copied, copyError = Files.copy(renderedPath, partial)
    if copied then copied, copyError = Files.move(partial, destination) end
    if not copied then
        -- 复制失败的半文件不允许通过重试提交。保留 LR 原渲染文件，由用户重新导出。
        Files.delete(partial)
        error('无法保存临时修图，请检查统一暂存目录写入权限：' .. tostring(copyError))
    end
    return { originalPath = originalPath, retouchedPath = destination }
end

-- persist 在成片写完后保存版本化批次清单，完成原子发布后才允许网络提交。
function Bridge.persist(connection, items)
    assert(#items > 0 and #items <= 100, '清单必须包含 1 至 100 张')
    Files.createAllDirectories(jobsDirectory)
    local path
    repeat
        local stamp = math.floor((Date.currentTime() + 978307200) * 1000)
        path = Paths.child(jobsDirectory, string.format('%.0f-%09d.json', stamp, math.random(1, 999999999)))
    until not Files.exists(path) and not Files.exists(path .. '.partial')
    local manifest = { version = 1, libraryPath = connection.libraryPath, items = items }
    local file, openError = io.open(path .. '.partial', 'wb')
    assert(file, '无法保存回传清单：' .. tostring(openError))
    local written, writeError = file:write(Json.encode(manifest))
    local closed, closeError = file:close()
    if not written or not closed then
        Files.delete(path .. '.partial')
        error('无法保存回传清单，成片保留在暂存目录：' .. tostring(writeError or closeError))
    end
    local published, publishError = Files.move(path .. '.partial', path)
    assert(published, '无法发布回传清单：' .. tostring(publishError))
    return path
end

-- loadManifest 每次发送都重新读取磁盘清单，未知格式拒绝提交，避免误解原图关系。
function Bridge.loadManifest(path)
    local manifest = readJSON(path)
    assert(type(manifest) == 'table' and manifest.version == 1, '回传清单版本不受支持，请保留文件并更新插件')
    assert(type(manifest.libraryPath) == 'string' and type(manifest.items) == 'table'
        and #manifest.items > 0 and #manifest.items <= 100, '回传清单内容无效')
    local seen = {}
    for _, item in ipairs(manifest.items) do
        assert(type(item) == 'table' and type(item.originalPath) == 'string' and item.originalPath:sub(1, 1) == '/'
            and type(item.retouchedPath) == 'string' and item.retouchedPath:sub(1, 1) == '/', '清单中的图片路径无效')
        assert(not seen[item.retouchedPath], '清单包含重复的临时成片')
        seen[item.retouchedPath] = true
    end
    return manifest
end

-- pending 只列出完整发布的清单，半文件不提交；损坏或未知版本在重试时明确报告。
function Bridge.pending()
    local paths = {}
    if not Files.exists(jobsDirectory) then return paths end
    for path in Files.files(jobsDirectory) do
        if path:match('%.json$') then paths[#paths + 1] = path end
    end
    table.sort(paths)
    return paths
end

-- send 从同一 JSON 清单提交；部分失败保留完整清单，成功项通过图库幂等记录避免重复入库。
function Bridge.send(connection, manifestPath)
    local manifest = Bridge.loadManifest(manifestPath)
    assert(manifest.libraryPath == connection.libraryPath, '目标图库已切换，请回到原图库后重试')
    local body = Http.post(connection.baseURL .. '/openapi/v1/retouch/imports', Json.encode({ items = manifest.items }), {
        { field = 'Content-Type', value = 'application/json' },
        { field = 'X-Luma-Instance', value = connection.instanceToken },
    }, 'POST', 600)
    local parsed, response = pcall(Json.decode, body)
    local outcomes, complete = {}, true
    for _, item in ipairs(manifest.items) do
        local result, message
        if parsed then result, message = Core.matchResult(response, item)
        else message = '连接中断或响应无效，临时成片及清单已保留，可重试未完成回传。' end
        if not result or result.cleanupPending then complete = false end
        outcomes[#outcomes + 1] = {
            item = item,
            success = result ~= nil,
            cleanupPending = result and result.cleanupPending or false,
            message = message,
        }
    end
    -- 图库已确认整批接收及临时清理后，才清理这一份不可变清单。
    if complete then Files.delete(manifestPath) end
    return outcomes
end

-- guarded 避免同一插件内导出和手动重试重复操作，使用可让出执行权的 SDK pcall。
function Bridge.guarded(action)
    if _G.LumaIndexRetouchBusy then return false, '已有回传正在进行，请等待完成。' end
    _G.LumaIndexRetouchBusy = true
    local success, result = Tasks.pcall(action)
    _G.LumaIndexRetouchBusy = false
    return success, result
end
return Bridge
