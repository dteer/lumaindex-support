local Tasks = import 'LrTasks'
local Dialogs = import 'LrDialogs'
local Bridge = dofile(_PLUGIN.path .. '/Bridge.lua')
Tasks.startAsyncTask(function()
    local ok, message = Bridge.guarded(function()
        local connection, err = Bridge.current()
        assert(connection, err)
        local success, failed, skipped, invalid = 0, 0, 0, 0
        for _, path in ipairs(Bridge.pending()) do
            local loaded, manifest = pcall(Bridge.loadManifest, path)
            if not loaded then
                invalid = invalid + 1
            elseif manifest.libraryPath ~= connection.libraryPath then
                skipped = skipped + #manifest.items
            else
                for _, outcome in ipairs(Bridge.send(connection, path)) do
                    if outcome.success and not outcome.cleanupPending then success = success + 1 else failed = failed + 1 end
                end
            end
        end
        local warning = invalid > 0 and '\n存在无法读取或版本不支持的清单，已保留，请更新插件并检查清单。' or ''
        Dialogs.message('有序图库', string.format('已完成 %d 张，仍待处理 %d 张。\n其他图库的 %d 条记录保持不变。', success, failed, skipped) .. warning, (failed > 0 or invalid > 0) and 'warning' or 'info')
    end)
    if not ok then Dialogs.message('有序图库', tostring(message), 'warning') end
end)
