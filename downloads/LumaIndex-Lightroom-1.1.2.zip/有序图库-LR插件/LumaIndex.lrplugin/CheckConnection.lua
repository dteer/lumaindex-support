local Tasks = import 'LrTasks'
local Dialogs = import 'LrDialogs'
local Bridge = dofile(_PLUGIN.path .. '/Bridge.lua')
Tasks.startAsyncTask(function()
    local ok, err = Tasks.pcall(function()
        local connection, message = Bridge.current()
        Dialogs.message('有序图库', connection and ('连接成功\n当前图库：' .. connection.libraryPath) or message, connection and 'info' or 'warning')
    end)
    if not ok then Dialogs.message('有序图库', tostring(err), 'warning') end
end)
