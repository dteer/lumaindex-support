-- 无 SDK 依赖的协议逻辑，便于用 Lua 5.1 单测覆盖路径、命名和响应判定。
local Core = {}

-- temporaryName 保持原图基名，使用 Unix 毫秒时间戳及九位随机数；碰撞时继续避让。
function Core.temporaryName(originalPath, renderedPath, milliseconds, last, randomNumber)
    local name = originalPath:match('([^/]+)$')
    assert(name, '原图路径无效')
    local base = name:gsub('%.[^%.]+$', '')
    local extension = renderedPath:match('%.([^%./]+)$')
    assert(extension, '导出图片没有扩展名')
    local stamp = math.max(math.floor(milliseconds), (last or 0) + 1)
    local random = randomNumber or math.random(1, 999999999)
    assert(type(random) == 'number' and random >= 1 and random <= 999999999 and random % 1 == 0, '无效随机数')
    return base .. '_' .. string.format('%.0f_%09d', stamp, random) .. '.' .. extension:lower(), stamp
end

-- validConnection 禁止把本机文件路径提交到远端地址。
function Core.validConnection(value)
    if type(value) ~= 'table' or type(value.baseURL) ~= 'string' then return false end
    local port = tonumber(value.baseURL:match('^http://127%.0%.0%.1:(%d+)$'))
    return port and port > 0 and port < 65536 and type(value.instanceToken) == 'string'
        and #value.instanceToken > 0 and type(value.libraryPath) == 'string' and value.libraryPath:sub(1, 1) == '/'
        and type(value.stagingDirectory) == 'string' and value.stagingDirectory:sub(1, 1) == '/'
end

-- matchResult 精确匹配请求路径；不把 HTTP 200 或外层 code=0 当作单图成功。
function Core.matchResult(response, item)
    if type(response) ~= 'table' or response.code ~= 0 or type(response.data) ~= 'table' or type(response.data.items) ~= 'table' then
        return nil, '图库未返回有效的逐张处理结果'
    end
    local found
    for _, result in ipairs(response.data.items) do
        if result.originalPath == item.originalPath and result.retouchedPath == item.retouchedPath then
            if found then return nil, '图库返回了重复的处理结果' end
            found = result
        end
    end
    if not found then return nil, '图库没有返回这张图片的处理结果' end
    if found.code ~= 0 then return nil, found.message or '接收失败' end
    if type(found.assetId) ~= 'string' or found.assetId == '' or type(found.savedPath) ~= 'string' or found.savedPath == '' then
        return nil, '图库返回的成片信息不完整'
    end
    return found
end
return Core
