-- 独立 JSON 编解码，兼容 Lightroom Lua 5.1；不使用 loadstring 执行响应内容。
local Json = {}
Json.null = {}

local escapes = { ['"'] = '\\"', ['\\'] = '\\\\', ['\b'] = '\\b', ['\f'] = '\\f', ['\n'] = '\\n', ['\r'] = '\\r', ['\t'] = '\\t' }
local function quote(value)
    return '"' .. value:gsub('[%z\1-\31\\"]', function(c)
        return escapes[c] or string.format('\\u%04x', c:byte())
    end) .. '"'
end

-- encode 仅序列化 JSON 值，拒绝循环引用及非有限数值。
function Json.encode(value)
    local seen = {}
    local function encode(v, depth)
        assert(depth < 64, 'JSON 嵌套过深')
        if v == nil or v == Json.null then return 'null' end
        if type(v) == 'string' then return quote(v) end
        if type(v) == 'boolean' then return tostring(v) end
        if type(v) == 'number' then
            assert(v == v and v ~= math.huge and v ~= -math.huge, '无效 JSON 数值')
            return string.format('%.17g', v)
        end
        assert(type(v) == 'table' and not seen[v], '无效或循环 JSON 对象')
        seen[v] = true
        local parts, count, array = {}, 0, true
        for key in pairs(v) do
            count = count + 1
            if type(key) ~= 'number' or key < 1 or key % 1 ~= 0 then array = false end
        end
        array = array and count > 0 and count == #v
        if array then
            for _, item in ipairs(v) do parts[#parts + 1] = encode(item, depth + 1) end
        else
            for key, item in pairs(v) do
                assert(type(key) == 'string', 'JSON 对象键必须是字符串')
                parts[#parts + 1] = quote(key) .. ':' .. encode(item, depth + 1)
            end
            table.sort(parts)
        end
        seen[v] = nil
        return (array and '[' or '{') .. table.concat(parts, ',') .. (array and ']' or '}')
    end
    return encode(value, 0)
end

local function utf8(code)
    if code < 128 then return string.char(code) end
    if code < 2048 then return string.char(192 + math.floor(code / 64), 128 + code % 64) end
    if code < 65536 then return string.char(224 + math.floor(code / 4096), 128 + math.floor(code / 64) % 64, 128 + code % 64) end
    return string.char(240 + math.floor(code / 262144), 128 + math.floor(code / 4096) % 64, 128 + math.floor(code / 64) % 64, 128 + code % 64)
end

-- decode 严格解析响应与本地交接记录，支持中文、转义及 UTF-16 代理对。
function Json.decode(input)
    assert(type(input) == 'string' and #input <= 4 * 1024 * 1024, 'JSON 内容无效或过大')
    local pos, parse = 1, nil
    local function skip() local _, last = input:find('^[ \t\r\n]*', pos); pos = (last or pos - 1) + 1 end
    local function hex4()
        local raw = input:sub(pos, pos + 3)
        assert(#raw == 4 and raw:match('^%x%x%x%x$'), '无效 Unicode 转义')
        pos = pos + 4
        return tonumber(raw, 16)
    end
    local function text()
        pos = pos + 1
        local parts = {}
        while pos <= #input do
            local c = input:sub(pos, pos); pos = pos + 1
            if c == '"' then return table.concat(parts) end
            if c == '\\' then
                local e = input:sub(pos, pos); pos = pos + 1
                local map = { ['"'] = '"', ['\\'] = '\\', ['/'] = '/', b = '\b', f = '\f', n = '\n', r = '\r', t = '\t' }
                if e == 'u' then
                    local code = hex4()
                    if code >= 0xd800 and code <= 0xdbff then
                        assert(input:sub(pos, pos + 1) == '\\u', '缺少 Unicode 代理对'); pos = pos + 2
                        local low = hex4(); assert(low >= 0xdc00 and low <= 0xdfff, '无效 Unicode 代理对')
                        code = 0x10000 + (code - 0xd800) * 1024 + low - 0xdc00
                    else assert(code < 0xdc00 or code > 0xdfff, '无效 Unicode 代理对') end
                    parts[#parts + 1] = utf8(code)
                else assert(map[e], '无效字符串转义'); parts[#parts + 1] = map[e] end
            else assert(c:byte() >= 32, '字符串含控制字符'); parts[#parts + 1] = c end
        end
        error('字符串未闭合')
    end
    parse = function(depth)
        assert(depth < 64, 'JSON 嵌套过深'); skip()
        local c = input:sub(pos, pos)
        if c == '"' then return text() end
        if c == '{' or c == '[' then
            local object, close, result = c == '{', c == '{' and '}' or ']', {}
            pos = pos + 1; skip()
            if input:sub(pos, pos) == close then pos = pos + 1; return result end
            while true do
                local key
                if object then
                    skip(); assert(input:sub(pos, pos) == '"', '对象键无效'); key = text(); skip()
                    assert(result[key] == nil, '对象键重复')
                    assert(input:sub(pos, pos) == ':', '缺少冒号'); pos = pos + 1
                else key = #result + 1 end
                result[key] = parse(depth + 1); skip()
                c = input:sub(pos, pos); pos = pos + 1
                if c == close then return result end
                assert(c == ',', '缺少分隔符')
            end
        end
        for token, value in pairs({ ['true'] = true, ['false'] = false, ['null'] = Json.null }) do
            if input:sub(pos, pos + #token - 1) == token then pos = pos + #token; return value end
        end
        local raw = input:sub(pos):match('^-?%d+%.?%d*[eE]?[+-]?%d*')
        assert(raw and not raw:match('^-?0%d') and not raw:match('%.$'), '无效 JSON 值')
        local value = tonumber(raw); assert(value and value ~= math.huge and value ~= -math.huge, '无效数字')
        pos = pos + #raw
        return value
    end
    local result = parse(0); skip(); assert(pos > #input, 'JSON 尾部含多余内容')
    return result
end
return Json
